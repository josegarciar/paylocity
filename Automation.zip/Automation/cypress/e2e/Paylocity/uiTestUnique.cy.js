/// <reference types="cypress" />

context('Login', () => {
  beforeEach(() => {
    //enter user and password for login
    cy.visit('https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login')
    cy.get('#Username').type('TestUser812')
    cy.get('#Username').should('have.value', 'TestUser812')

    cy.get('#Password').type(')}ocfn&U}7T@')
    cy.get('#Password').should('have.value', ')}ocfn&U}7T@')

    cy.get('.btn-primary').click()
  })

  it('Create, validate, update, and delete employee', () => {
    // Create employee record
    const randomDependants = Math.floor(Math.random() * 20) // 0 to 20 dependents
    const firstName = `Test${randomDependants}` // unique name using random dependent
    const lastName = 'User'
  
    cy.get('#add').click()
    cy.get('#firstName').type(firstName).should('have.value', firstName)
    cy.get('#lastName').type(lastName).should('have.value', lastName)
    cy.get('#dependants').type(`${randomDependants}`).should('have.value', `${randomDependants}`)
    cy.get('#addEmployee').click()
    cy.wait(500) // wait until page is loaded
  
    // Validate Cost and Pay
    const expectedBenefit = (1000 / 26) + (randomDependants * 500 / 26)
    const expectedBenefitRounded = expectedBenefit.toFixed(2)
    const netPay = 2000 - expectedBenefitRounded
    const netPayRounded= netPay.toFixed(2)
  
    cy.get('#employeesTable tbody tr').contains('td', firstName).parent('tr').within(() => {
      cy.get('td').eq(6).invoke('text').then(text => { // column 7 = Benefits Cost
        const tableCost = parseFloat(text.trim())
        expect(tableCost).to.eq(parseFloat(expectedBenefitRounded))
      })
    })
    cy.get('#employeesTable tbody tr').contains('td', firstName).parent('tr').within(() => {
      cy.get('td').eq(7).invoke('text').then(text => { // column 8 = Net Pay
        const tableCost = parseFloat(text.trim())
        expect(tableCost).to.eq(parseFloat(netPayRounded))
      })
    })
  
    // Update the firstName and lastName
    const updatedFirstName = firstName + '_Updated'
    const updatedLastName = lastName + '_Updated'
  // click on the edit icon
    cy.get('#employeesTable tbody tr').contains('td', firstName).parent('tr').within(() => {
      cy.get('.fas.fa-edit').click()
    })
  // Update the firs tname and last name
    cy.get('#firstName').clear().type(updatedFirstName).should('have.value', updatedFirstName)
    cy.get('#lastName').clear().type(updatedLastName).should('have.value', updatedLastName)
    cy.get('#updateEmployee').click()
    cy.wait(500)
  
    // Click on the delete button for a record
    cy.get('#employeesTable tbody tr').contains('td', updatedFirstName).parent('tr').within(() => {
      cy.get('.fas.fa-times').click()
    })
    cy.get('#deleteEmployee').click()
    cy.wait(500)
  
    // Validación final: el empleado ya no debe existir
    cy.get('#employeesTable tbody').should('not.contain', updatedFirstName)
  })
    })