/// <reference types="cypress" />

context('Actions', () => {
  beforeEach(() => {
    //enter user and password for login
    cy.visit('https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login')
    cy.get('#Username').type('TestUser812')
    cy.get('#Username').should('have.value', 'TestUser812')

    cy.get('#Password').type(')}ocfn&U}7T@')
    cy.get('#Password').should('have.value', ')}ocfn&U}7T@')
  
    cy.get('.btn-primary').click()
  })
// Create employee records
for (let i = 1; i <= 5; i++) { // 5 employee records
  it(`Add Employee ${i}`, () => {
    const firstName = `Test ${i}` // first name Test + i value
    const dependants = Math.floor(Math.random() * 20) // 0 to 20 random dependents
    cy.get('#add').click()
    cy.get('#firstName').type(firstName)
    cy.get('#firstName').should('have.value', firstName)

    cy.get('#lastName').type('test')
    cy.get('#lastName').should('have.value', 'test')

    cy.get('#dependants').type(dependants)
    cy.get('#dependants').should('have.value', dependants)

    cy.get('#addEmployee').click()
    cy.wait(300)
  })
}

// validate the Salary and Gross
it('Validate all employee records', () => {
  cy.get('#employeesTable tbody tr').each(($row) => {
    // Salary: must be 52000.00
    cy.wrap($row).find('td').eq(4).invoke('text').then((salaryText) => {
      const salary = parseFloat(salaryText.trim())
      expect(salary).to.eq(52000.00)
    })

    // Gross Pay: must be 2000.00
    cy.wrap($row).find('td').eq(5).invoke('text').then((grossPayText) => {
      const grossPay = parseFloat(grossPayText.trim())
      expect(grossPay).to.eq(2000.00)
    })

    // Benefits Cost y Net Pay must be calculated
    cy.wrap($row).find('td').eq(3).invoke('text').then((depText) => {
      const dependants = parseInt(depText.trim(), 10)

      const expectedBenefit = ((1000 / 26) + (dependants * 500 / 26)).toFixed(2)
      const expectedNetPay = (2000 - parseFloat(expectedBenefit)).toFixed(2)

      cy.wrap($row).find('td').eq(6).invoke('text').then((benefitText) => {
        expect(parseFloat(benefitText.trim())).to.eq(parseFloat(expectedBenefit))
      })

      cy.wrap($row).find('td').eq(7).invoke('text').then((netPayText) => {
        expect(parseFloat(netPayText.trim())).to.eq(parseFloat(expectedNetPay))
      })
    })
  })
})

  it('Update a random employee', () => {
    // wait until update window is displayed
    cy.get('.fas.fa-edit', { timeout: 5000 }).should('exist').then($editar => {
      const count = $editar.length
  
      // random index to update a employee record
      const randomIndex = Math.floor(Math.random() * count)
  
      cy.wrap($editar.eq(randomIndex)).click()
      cy.wait(500)
  
      // update fields
      cy.get('#firstName').clear().type('updated').should('have.value', 'updated')
      cy.get('#lastName').clear().type('updated').should('have.value', 'updated')
      cy.get('#updateEmployee').click()
      cy.wait(300)
  
      cy.log(`employee updated #${randomIndex + 1}`)
    })
  })
  //Delete the employee records displayed
it('Delete the employee records displayed', () => {
  cy.get('.fas.fa-times').its('length').then(count => {
    if (count > 0) {
      // delete all employee records displayed
      for (let i = 0; i < count; i++) {
        cy.get('.fas.fa-times').first().click()
        cy.wait(500)
        cy.get('#deleteEmployee').click()
        cy.wait(500)
      }
    } else {
      //if there is no records, continue
      cy.log('There is no records to update')
    }
  })
})

})
