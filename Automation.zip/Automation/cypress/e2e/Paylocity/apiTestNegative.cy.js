describe('API Error Handling', () => {
  const baseUrl = 'https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees/'
  const authToken = 'Basic VGVzdFVzZXI4MTI6KX1vY2ZuJlV9N1RA'
  const headers = { Authorization: authToken }

  it('GET non-existent employee should fail', () => {
    cy.request({
      method: 'GET',
      url: `${baseUrl}non-existent-id`,
      headers,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 404, 500]) // depende de tu API
    })
  })

  it('POST employee with missing fields should fail', () => {
    const invalidBody = {
      firstName: 'BadRequest'
      // Falta lastName and dependants
    }

    cy.request({
      method: 'POST',
      url: baseUrl,
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 422]) // error esperado
    })
  })
  it('POST employee with empty data should fail', () => {
    const invalidBody = {
     
    }

    cy.request({
      method: 'POST',
      url: baseUrl,
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 422]) // error esperado
    })
  })

  it('POST employee with first name with more than 50 chars should fail', () => {
    const invalidBody = {
      firstName: 'asdfghjklñasdfghjklñasdfghjklñasdfghjklñasdfghjklñasdfghjklñ',
      lastName: 'User',
      dependants: 1
    }
    cy.request({
      method: 'POST',
      url: baseUrl,
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 422]) // error esperado
    })
  })
  it('POST employee with last name with more than 50 chars should fail', () => {
    const invalidBody = {
      firstName: 'Test',
      lastName: 'asdfghjklñasdfghjklñasdfghjklñasdfghjklñasdfghjklñasdfghjklñ',
      dependants: 1
    }
    cy.request({
      method: 'POST',
      url: baseUrl,
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 422]) // error esperado
    })
  })
  it('POST employee with dependent >32 should fail', () => {
    const invalidBody = {
      firstName: 'Test',
      lastName: 'user',
      dependants: 33
    }
    cy.request({
      method: 'POST',
      url: baseUrl,
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 422]) // error esperado
    })
  })
  it('PUT with invalid id should fail', () => {
    const invalidBody = {
      id: 'fake-id',
      sortKey: 'fake-id',
      firstName: 'Invalid',
      lastName: 'User',
      dependants: 1
    }

    cy.request({
      method: 'PUT',
      url: baseUrl,   // tu API no soporta PUT en /{id}, así que probamos en base
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 404, 405])
    })
  })
  it('PUT with no data should fail', () => {
    const invalidBody = {
      
    }

    cy.request({
      method: 'PUT',
      url: baseUrl,   // tu API no soporta PUT en /{id}, así que probamos en base
      headers,
      body: invalidBody,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 404, 405])
    })
  })
  it('DELETE non-existent employee should fail', () => {
    cy.request({
      method: 'DELETE',
      url: `${baseUrl}non-existent-id`,
      headers,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 404, 405])
    })
  })
  it('DELETE with empty employee should fail', () => {
    cy.request({
      method: 'DELETE',
      url: `${baseUrl}`,
      headers,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.be.oneOf([400, 404, 405])
    })
  })
})
